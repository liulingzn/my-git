
import { _decorator, Component, Node, Collider, ITriggerEvent, Director } from 'cc';
const { ccclass, property } = _decorator;
import { Constent } from '../framework/Constent';
const moveMaxLength = 50
const moveMinLength = -50
@ccclass('Bullet')
export class Bullet extends Component {


    public _bullSpeed: number = 60

    public _isEnemyBullet: boolean = false

    public _direction = Constent.Direction.MIDDLE

    start() {
        // [3]
    }
    onEnable() {
        const collider = this.getComponent(Collider);
        collider.on('onTriggerEnter', this._onTriggerEnter, this);
    }
    onDisable() {
        const collider = this.getComponent(Collider);
        collider.off('onTriggerEnter', this._onTriggerEnter, this);
    }
    private _onTriggerEnter(event: ITriggerEvent) {
       

        this.node.destroy();

    }

    update(deltaTime: number) {
        // [4]
        this.bulletMove(deltaTime)
    }

    private bulletMove(dt: number): void {
        const pos = this.node.getPosition()
        let moveLength = pos.z - this._bullSpeed * dt

        if (this._isEnemyBullet) {
            moveLength = pos.z + this._bullSpeed * dt
            this.node.setPosition(pos.x, pos.y, moveLength)
            if (moveLength > moveMaxLength) {
                this.node.destroy();

            }
        } else {
            moveLength = pos.z - this._bullSpeed * dt


            if (this._direction === Constent.Direction.LEFT) {
                this.node.setPosition(pos.x - this._bullSpeed * 0.005, pos.y, moveLength)
            } else if (this._direction === Constent.Direction.RIGHR) {
                this.node.setPosition(pos.x + this._bullSpeed * 0.005, pos.y, moveLength)
            } else {
                this.node.setPosition(pos.x, pos.y, moveLength)
            }


            if (moveLength < moveMinLength) {
                this.node.destroy();

            }
        }


    }
    public show(speed: number, bulletType: boolean, dire: number = Constent.Direction.MIDDLE) {
        this._bullSpeed = speed;
        this._isEnemyBullet = bulletType;
        this._direction = dire;

    }
}


