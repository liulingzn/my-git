
import { _decorator, Component, Node, Collider, ITriggerEvent, ConeCollider } from 'cc';
import { Constent } from '../framework/Constent';
import { GameManger } from '../framework/GameManger';
const { ccclass, property } = _decorator;

/**
 * Predefined variables
 * Name = bulletProp
 * DateTime = Tue May 31 2022 18:12:23 GMT+0800 (中国标准时间)
 * Author = liulingzn
 * FileBasename = bulletProp.ts
 * FileBasenameNoExtension = bulletProp
 * URL = db://assets/script/bullite/bulletProp.ts
 * ManualUrl = https://docs.cocos.com/creator/3.4/manual/zh/
 *
 */

@ccclass('bulletProp')
export class bulletProp extends Component {

    private propSpeed = 0.3
    private propXspeed = 0.3


    private _gameManger: GameManger

    onEnable() {
        const collider = this.getComponent(Collider);
        collider.on('onTriggerEnter', this._onTriggerEnter, this);
    }
    onDisable() {
        const collider = this.getComponent(Collider);
        collider.off('onTriggerEnter', this._onTriggerEnter, this);
    }
    private _onTriggerEnter(event: ITriggerEvent) {

     

        const name = event.selfCollider.node.name;
        
        if (name === 'bulletm') {
            this._gameManger.changeBulletPropType(Constent.BulletPropType.BULLET_M)
        }else if(name === 'bulleth') {
            this._gameManger.changeBulletPropType(Constent.BulletPropType.BULLET_H)
        }else{
            this._gameManger.changeBulletPropType(Constent.BulletPropType.BULLET_S)
        }

        this.node.destroy()
    }

    update(deltaTime: number) {
        // [4]
        this.moveFunc(deltaTime);

    }

    private moveFunc(dt: number) {
        let pos = this.node.position;

        if (pos.x >= 15) {
            this.propXspeed = -this.propSpeed;
        } else if (pos.x <= -15) {
            this.propXspeed = this.propSpeed;
        }
           
            
        this.node.setPosition(pos.x + this.propXspeed, pos.y, pos.z + this.propSpeed);

        pos = this.node.position;
        if ( pos.z  > 50) {
            this.node.destroy();
        }
    }
    public show(speed: number, manger: GameManger) {
        // this.propSpeed = speed;
        this._gameManger = manger;
    }


}

/**
 * [1] Class member could be defined like this.
 * [2] Use `property` decorator if your want the member to be serializable.
 * [3] Your initialization goes here.
 * [4] Your update function goes here.
 *
 * Learn more about scripting: https://docs.cocos.com/creator/3.4/manual/zh/scripting/
 * Learn more about CCClass: https://docs.cocos.com/creator/3.4/manual/zh/scripting/decorator.html
 * Learn more about life-cycle callbacks: https://docs.cocos.com/creator/3.4/manual/zh/scripting/life-cycle-callbacks.html
 */
