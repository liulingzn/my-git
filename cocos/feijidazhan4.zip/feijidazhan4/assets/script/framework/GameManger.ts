
import { _decorator, Component, Node, instantiate, Prefab, math, Vec3, BoxCollider, macro, Label, ProgressBar } from 'cc';
import { Bullet } from '../bullite/Bullet';
import { bulletProp } from '../bullite/bulletProp';
import { enemyPlay } from '../plane/enemyPlay';
import { selfPlane } from '../plane/selfPlane';
import { AudioManger } from './AudioManger';
import { Constent } from './Constent';
const { ccclass, property } = _decorator;

/**
 * Predefined variables
 * Name = GameManger
 * DateTime = Thu May 26 2022 10:04:38 GMT+0800 (中国标准时间)
 * Author = liulingzn
 * FileBasename = GameManger.ts
 * FileBasenameNoExtension = GameManger
 * URL = db://assets/script/framework/GameManger.ts
 * ManualUrl = https://docs.cocos.com/creator/3.4/manual/zh/
 *
 */

const movsPosition = [
    -21, 0, -60,
    -14, 0, -55,
    -7, 0, -50,
    0, 0, -45,
    7, 0, -50,
    14, 0, -55,
    21, 0, -60,
]

@ccclass('GameManger')
export class GameManger extends Component {
    @property({ type: selfPlane, tooltip: "玩家飞机" })
    public playerPlane: selfPlane = null;

    @property({ type: Prefab, tooltip: "子弹01" })
    public bullet01: Prefab = null;

    @property({ type: Prefab, tooltip: "子弹02" })
    public bullet02: Prefab = null;

    @property({ type: Prefab, tooltip: "子弹03" })
    public bullet03: Prefab = null;

    @property({ type: Prefab, tooltip: "子弹04" })
    public bullet04: Prefab = null;

    @property({ type: Prefab, tooltip: "子弹05" })
    public bullet05: Prefab = null;

    @property({ type: Node, tooltip: "子弹管理" })
    public bulletRoot: Node = null;


    @property({ type: Prefab, tooltip: "敌机1号" })
    public enemy01: Prefab = null;


    @property({ type: Prefab, tooltip: "敌机2号" })
    public enemy02: Prefab = null;


    @property({ type: Prefab, tooltip: "道具M" })
    public propm: Prefab = null;
    @property({ type: Prefab, tooltip: "道具h" })
    public proph: Prefab = null;
    @property({ type: Prefab, tooltip: "道具s" })
    public props: Prefab = null;


    @property({ type: Node, tooltip: "游戏页面" })
    public gamePage: Node = null;

    @property({ type: Node, tooltip: "游戏结算页面" })
    public gameOverPage: Node = null;

    @property({ type: Label, tooltip: "页面分数" })
    public gameScore: Label = null;

    @property({ type: Label, tooltip: "结束页面统计分数" })
    public gameOverScoer: Label = null;

   


    @property ({type:AudioManger,tooltip:"音效"})
    public audioEffect:AudioManger=null;

    public creatEnemyTime = 1

    public enemy1Speed = 20

    public enemy2Speed = 30


    public bulletSpeed = 90;

    public shootTimer = 0.2;

    private _currShoolTimer = 0;
    private _isShootling = false;
    private _currCreatEnemmyTime = 0;
    private _combinationInterval = 1;

    private _bulletPropType: number = Constent.BulletPropType.BULLET_M;


    public isGameStart: boolean = false;


    public _score: number = 0;

    start() {
        // [3]
        this.gameInit();
    }

    update(deltaTime: number) {
        if(!this.isGameStart){
            return
        }
        // console.log(Constent.planeLife);
        
        if(Constent.planeLife<=0){
            this.gameOverFunc();
            return
        }
        this._currShoolTimer += deltaTime;
        this.emission();

        this._currCreatEnemmyTime += deltaTime
        if (this._combinationInterval === Constent.Combination.PLAN1) {

            if (this._currCreatEnemmyTime > this.creatEnemyTime) {
                this._currCreatEnemmyTime = 0
                this.creatEnemyPlane()
            }

        } else if (this._combinationInterval === Constent.Combination.PLAN2) {
            if (this._currCreatEnemmyTime > this.creatEnemyTime * 0.8) {
                this._currCreatEnemmyTime = 0


                const typeNum = math.randomRangeInt(1, 3)
                if (typeNum === Constent.Combination.PLAN2) {
                    this.formationOne()
                } else {
                    this.creatEnemyPlane()
                }

                // this.formationOne()
            }

        } else {

            if (this._currCreatEnemmyTime > this.creatEnemyTime * 0.8) {
                this._currCreatEnemmyTime = 0


                const typeNum = math.randomRangeInt(1, 4)
                if (typeNum === Constent.Combination.PLAN2) {
                    this.formationOne()
                } else if (typeNum === Constent.Combination.PLAN3) {
                    this.formationTwo()
                } else {
                    this.creatEnemyPlane()
                }


            }
        }
    }
    public  playAudio(name:string){
        this.audioEffect.playEffect(name)
    }
    public againGame() {
        this._currShoolTimer = 0;
        this._isShootling = false;
        this._currCreatEnemmyTime = 0;
        this._combinationInterval = 1;

        this._bulletPropType = Constent.BulletPropType.BULLET_M
        // this.isGameStart = true
        this.gameStartFunc()
    }

    public returnMain() {
        this._currShoolTimer = 0;
        this._isShootling = false;
        this._currCreatEnemmyTime = 0;
        this._combinationInterval = 1;
        this.playerPlane.node.setPosition(0, 0, 15);
        this._score = 0;
        this._bulletPropType = Constent.BulletPropType.BULLET_M;
        
    }

    public gameOverFunc() {
        this.isGameStart = false;   


        this.gamePage.active = false;
        this.gameOverScoer.string = this._score.toString();
        this.gameOverPage.active = true;
        this._isShootling = false;
        this.unschedule(this.modeChange);
        this.disableAll();
        this.playAudio("player")
    }

    public gameStartFunc() {

        this.isGameStart = true
        this.changePlaneModel()
        this.playerPlane.node.setPosition(0, 0, 15);
        Constent.planeLife=10;
        this._score=0;
        this.gameScore.string = this._score.toString();
        this.playerPlane.planeInit()
    }
    public disableAll() {

        this.node.destroyAllChildren()
        this.bulletRoot.destroyAllChildren()
    }

    public extraPoint() {
        this._score++;
        this.gameScore.string = this._score.toString();
        this.playAudio("enemy")
    }

    private creatEnemyPlane() {
        const which = math.randomRangeInt(1, 3);
        let prefab: Prefab = null;
        let speed = 0;
        if (which === Constent.ememyType.TYPE1) {
            prefab = this.enemy01;
            speed = this.enemy1Speed
        } else {
            prefab = this.enemy02
            speed = this.enemy2Speed
        }

        const enemy = instantiate(prefab);
        enemy.setParent(this.node);

        let enemyComp = enemy.getComponent(enemyPlay);
        enemyComp.show(speed, true, this);

        const create_x = math.randomRange(-25, 25);

        enemy.setPosition(create_x, 0, -50);


    }

    private formationOne() {
        for (let i = 0; i < 5; i++) {
            const element = instantiate(this.enemy02);
            element.setPosition(-20 + i * 10, 0, -50);
            element.setParent(this.node);
            const enemyCom = element.getComponent(enemyPlay)
            enemyCom.show(this.enemy1Speed, false ,this)
        }


    }

    private formationTwo() {


        for (let i = 0; i < 7; i++) {
            const element = instantiate(this.enemy02);
            const indexs = i * 3
            element.setPosition(movsPosition[indexs], movsPosition[indexs + 1], movsPosition[indexs + 2]);
            element.setParent(this.node);
            const enemyCom = element.getComponent(enemyPlay)
            enemyCom.show(this.enemy1Speed, false,this)
        }


    }

    private emission() {
        if (this._isShootling && this._currShoolTimer > this.shootTimer) {


            if (this._bulletPropType === Constent.BulletPropType.BULLET_S) {
                this.createPlayerBulletS()
            } else if (this._bulletPropType === Constent.BulletPropType.BULLET_H) {
                this.createPlayerBulletH()
            } else {
                this.createPlayerBulletM()
            }
           const effectname=(this._bulletPropType%2+1)
           this.playAudio("bullet"+effectname)
            this._currShoolTimer = 0

        }


    }

    private createPlayerBulletM() {
        const bullet = instantiate(this.bullet01);
        bullet.setParent(this.bulletRoot);
        const pos = this.playerPlane.node.getPosition();
        bullet.setPosition(pos.x, pos.y, pos.z - 7);

        const bulletCom = bullet.getComponent(Bullet);
        bulletCom.show(this.bulletSpeed, false)
    }

    private createPlayerBulletH() {
        const pos = this.playerPlane.node.getPosition();

        // right
        const bullet = instantiate(this.bullet03);
        bullet.setParent(this.bulletRoot);
        bullet.setPosition(pos.x + 2.5, pos.y, pos.z - 7);
        const bulletCom = bullet.getComponent(Bullet);
        bulletCom.show(this.bulletSpeed, false)
        // left
        const bullet1 = instantiate(this.bullet03);
        bullet1.setParent(this.bulletRoot);
        bullet1.setPosition(pos.x - 2.5, pos.y, pos.z - 7);
        const bulletCom1 = bullet1.getComponent(Bullet);
        bulletCom1.show(this.bulletSpeed, false)
    }

    private createPlayerBulletS() {
        const pos = this.playerPlane.node.getPosition();

        // right
        const bullet = instantiate(this.bullet05);
        bullet.setParent(this.bulletRoot);
        bullet.setPosition(pos.x + 4, pos.y, pos.z - 7);
        const bulletCom = bullet.getComponent(Bullet);
        bulletCom.show(this.bulletSpeed, false, Constent.Direction.RIGHR)
        // left
        const bullet1 = instantiate(this.bullet05);
        bullet1.setParent(this.bulletRoot);
        bullet1.setPosition(pos.x - 4, pos.y, pos.z - 7);
        const bulletCom1 = bullet1.getComponent(Bullet);
        bulletCom1.show(this.bulletSpeed, false, Constent.Direction.LEFT)


        // center
        const bullet2 = instantiate(this.bullet05);
        bullet2.setParent(this.bulletRoot);
        bullet2.setPosition(pos.x, pos.y, pos.z - 7);
        const bulletCom2 = bullet2.getComponent(Bullet);
        bulletCom2.show(this.bulletSpeed, false)
    }


    public createEnemyBullet(pos: Vec3) {
        const bullet = instantiate(this.bullet01);
        bullet.setParent(this.bulletRoot);
        bullet.setPosition(pos.x, pos.y, pos.z + 6);

        const bulletCom = bullet.getComponent(Bullet);
        bulletCom.show(60, true);

        const colliderComp = bullet.getComponent(BoxCollider);
        colliderComp.setGroup(Constent.CollisionType.ENEMY_BULLET);
        colliderComp.setMask(Constent.CollisionType.SELF_PLANE)
    }

    public changeBulletPropType(type: number) {
        this._bulletPropType = type
    }

    private creatBulletProp() {

        const propType = math.randomRangeInt(1, 4)

        let _prefab: Prefab = null
        if (propType === Constent.BulletPropType.BULLET_M) {
            _prefab = this.propm
        } else if (propType === Constent.BulletPropType.BULLET_H) {
            _prefab = this.proph
        } else {
            _prefab = this.props
        }
        const prop = instantiate(_prefab)

        prop.setParent(this.node)
        prop.setPosition(15, 0, -50)
        const propCom = prop.getComponent(bulletProp)
        propCom.show(30, this)
    }


    private gameInit() {
        this._currShoolTimer = this.shootTimer;

    }

    public setShooting(shoot: boolean): void {
       
        this._isShootling = shoot;
    }

    private changePlaneModel() {

        this.schedule(this.modeChange, 8, macro.REPEAT_FOREVER)

    }

    private modeChange() {
        this._combinationInterval++
        this.creatBulletProp()
    }
}

