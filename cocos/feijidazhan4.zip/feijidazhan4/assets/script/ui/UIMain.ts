
import { _decorator, Component, Node, systemEvent, SystemEvent, EventTouch, Touch } from 'cc';
import { GameManger } from '../framework/GameManger';
const { ccclass, property } = _decorator;

/**
 * Predefined variables
 * Name = UIMain
 * DateTime = Wed May 25 2022 17:33:42 GMT+0800 (中国标准时间)
 * Author = liulingzn
 * FileBasename = UIMain.ts
 * FileBasenameNoExtension = UIMain
 * URL = db://assets/script/ui/UIMain.ts
 * ManualUrl = https://docs.cocos.com/creator/3.4/manual/zh/
 *
 */

@ccclass('UIMain')
export class UIMain extends Component {
    // [1]
    // dummy = '';


    @property({ type: Node, tooltip: "我的战机" })
    playerPlane: Node = null;


    @property({ type: GameManger, tooltip: '管理类' })
    private gameMamger: GameManger = null;



    @property({ type: Node, tooltip: "开始页面" })
    public startGame: Node = null;

    @property({ type: Node, tooltip: "游戏页面" })
    public game: Node = null;

    @property({ type: Node, tooltip: "游戏结束" })
    public gameover: Node = null;



    private speedNumber = 0.068;
    start() {
        this.node.on(SystemEvent.EventType.TOUCH_START, this.touchStartFunc, this)
        this.node.on(SystemEvent.EventType.TOUCH_MOVE, this.touchMoveFunc, this)
        this.node.on(SystemEvent.EventType.TOUCH_END, this.touchEndFunc, this)
    }


    public againFunc() {
        this.gameover.active = false;
        this.game.active = true;
        this.gameMamger.againGame();
        this.gameMamger.playAudio("button");

    }

    public goUImain() {
        this.gameover.active = false;
        this.startGame.active = true;
        this.gameMamger.returnMain();
        this.gameMamger.playAudio("button");
    }

    // update (deltaTime: number) {
    //     // [4]
    // }
    private touchStartFunc(): void {
        if (!this.gameMamger.isGameStart) {
            this.startGame.active = false;
            this.game.active = true;
            this.gameMamger.gameStartFunc();

            this.gameMamger.playAudio("button");
            return
        }
        this.gameMamger.setShooting(true)
    }

    private touchMoveFunc(touch: Touch, event: EventTouch): void {
        if (!this.gameMamger.isGameStart) {
            return
        }
        let delta = touch.getDelta()
        let pos = this.playerPlane.position
        this.playerPlane.setPosition(pos.x + delta.x * this.speedNumber, pos.y, pos.z - delta.y * this.speedNumber)
    }

    private touchEndFunc(): void {
        if (!this.gameMamger.isGameStart) {
            return
        }
        this.gameMamger.setShooting(false)
    }

}

/**
 * [1] Class member could be defined like this.
 * [2] Use `property` decorator if your want the member to be serializable.
 * [3] Your initialization goes here.
 * [4] Your update function goes here.
 *
 * Learn more about scripting: https://docs.cocos.com/creator/3.4/manual/zh/scripting/
 * Learn more about CCClass: https://docs.cocos.com/creator/3.4/manual/zh/scripting/decorator.html
 * Learn more about life-cycle callbacks: https://docs.cocos.com/creator/3.4/manual/zh/scripting/life-cycle-callbacks.html
 */
