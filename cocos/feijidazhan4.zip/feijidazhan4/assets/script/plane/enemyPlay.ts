
import { _decorator, Component, Node, Collider, ITriggerEvent } from 'cc';
import { Constent } from '../framework/Constent';
import { GameManger } from '../framework/GameManger';
const { ccclass, property } = _decorator;

/**
 * Predefined variables
 * Name = enemyPlay
 * DateTime = Thu May 26 2022 15:23:08 GMT+0800 (中国标准时间)
 * Author = liulingzn
 * FileBasename = enemyPlay.ts
 * FileBasenameNoExtension = enemyPlay
 * URL = db://assets/script/plane/enemyPlay.ts
 * ManualUrl = https://docs.cocos.com/creator/3.4/manual/zh/
 *
 */

const deceaseBoundary: number = 50;

@ccclass('enemyPlay')
export class enemyPlay extends Component {

    public enemySpeed: number = 10

    // public enemyType=Constent.ememyType.TYPE1

    private createBulletTimer: number = 0.5
    private currCreateBullTime: number = 0
    private needBullet: boolean = false

    private _gameManger: GameManger = null
    start() {
        // [3]
    }

    onEnable() {
        const collider = this.getComponent(Collider);
        collider.on('onTriggerEnter', this._onTriggerEnter, this);
    }
    onDisable() {
        const collider = this.getComponent(Collider);
        collider.off('onTriggerEnter', this._onTriggerEnter, this);
    }
    private _onTriggerEnter(event: ITriggerEvent) {

        const collectGroup = event.otherCollider.getGroup();
        if (collectGroup === Constent.CollisionType.SELF_BULLET || collectGroup === Constent.CollisionType.SELF_PLANE) {
            this._gameManger.extraPoint();
            this.node.destroy();

        }

    }

    update(deltaTime: number) {
        // [4]
        this.enemyMove(deltaTime);
        if (this.needBullet) {
            this.emissionBullet(deltaTime)
        }
    }
    private emissionBullet(dt: number) {
        this.currCreateBullTime += dt
        if (this.currCreateBullTime > this.createBulletTimer) {
            this.currCreateBullTime = 0
            this._gameManger.createEnemyBullet(this.node.position)
        }

    }

    private enemyMove(dt: number) {
        const pos = this.node.getPosition();
        const movePlace = pos.z + dt * this.enemySpeed
        this.node.setPosition(pos.x, pos.y, movePlace)
        if (movePlace > deceaseBoundary) {
            this.node.destroy();

        }
    }

    public show(speed: number, isNeedBull: boolean, gameManger: GameManger = null) {
        this._gameManger = gameManger
        this.enemySpeed = speed
        this.needBullet = isNeedBull
    }
}

