
import { _decorator, Component, Node, systemEvent, SystemEvent, EventTouch, Touch, Collider, ITriggerEvent ,ProgressBar} from 'cc';
import { Constent } from '../framework/Constent';
const { ccclass, property } = _decorator;

/**
 * Predefined variables
 * Name = selfPlane
 * DateTime = Wed May 25 2022 16:27:02 GMT+0800 (中国标准时间)
 * Author = liulingzn
 * FileBasename = selfPlane.ts
 * FileBasenameNoExtension = selfPlane
 * URL = db://assets/script/selfPlane.ts
 * ManualUrl = https://docs.cocos.com/creator/3.4/manual/zh/
 *
 */

@ccclass('selfPlane')
export class selfPlane extends Component {

    @property({ type: ProgressBar, tooltip: "血量" })
    public lifePass: ProgressBar = null;

    public lifePassValue:ProgressBar

    public lifeValue: number = 5;

    onEnable() {
        const collider = this.getComponent(Collider);
        collider.on('onTriggerEnter', this._onTriggerEnter, this);
    }
    onDisable() {
        const collider = this.getComponent(Collider);
        collider.off('onTriggerEnter', this._onTriggerEnter, this);
    }

    // public planeInit(){
    //     this.lifeValue=5; 
    //     // Constent.planeLife=this.lifeValue;
    // }
    public planeInit(){
        this.lifePass.progress=Constent.planeLife/10
    }

    private _onTriggerEnter(event: ITriggerEvent) {
        // console.log("ppppppp");

        const collectGroup = event.otherCollider.getGroup();
        if (collectGroup === Constent.CollisionType.ENEMY_BULLET || collectGroup === Constent.CollisionType.ENEMY_PLANE) {
            // console.log("掉血");
            // this.lifeValue--;
            Constent.planeLife--;
           
            this.lifePass.progress=Constent.planeLife/10
        }

    }


}

