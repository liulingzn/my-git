
import { _decorator, Component, Node } from 'cc';
const { ccclass, property } = _decorator;


@ccclass('movebg')
export class movebg extends Component {
  
    @property({ type: Node, tooltip: "背景1" })
    private bg01: Node = null;

    @property({ type: Node, tooltip: "背景2" })
    private bg02: Node = null;


    private moveSpeed=10;
    private bgLengthNumber=90


    onLoad(){
        this.bgInit()
    }

    private bgInit(){
        this.bg01.setPosition(0,0,0)
        this.bg02.setPosition(0,0,-this.bgLengthNumber)
    }

    update (deltaTime: number) {
        // [4]
        this.bgMove(deltaTime)
    }
    private bgMove(dt:number):void{
        this.bg01.setPosition(0,0,this.bg01.position.z+this.moveSpeed*dt)
        this.bg02.setPosition(0,0,this.bg02.position.z+this.moveSpeed*dt)

        if(this.bg01.position.z>this.bgLengthNumber){
         this.bg01.setPosition(0,0,this.bg02.position.z-this.bgLengthNumber)

        }else if(this.bg02.position.z>this.bgLengthNumber){
            this.bg02.setPosition(0,0,this.bg01.position.z-this.bgLengthNumber)
        }
    }
}


