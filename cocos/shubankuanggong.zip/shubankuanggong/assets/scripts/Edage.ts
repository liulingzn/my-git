
import { _decorator, Component, Node ,PhysicsSystem2D,EPhysics2DDrawFlags,Collider2D,Contact2DType,IPhysics2DContact} from 'cc';
import { hook } from './hook';
const { ccclass, property } = _decorator;

/**
 * Predefined variables
 * Name = Edage
 * DateTime = Mon Apr 25 2022 17:01:02 GMT+0800 (中国标准时间)
 * Author = liulingzn
 * FileBasename = Edage.ts
 * FileBasenameNoExtension = Edage
 * URL = db://assets/scripts/Edage.ts
 * ManualUrl = https://docs.cocos.com/creator/3.4/manual/zh/
 *
 */
 
@ccclass('Edage')
export class Edage extends Component {

    @property ({type:hook,tooltip:'触发回弹'})
    gouzi:hook=null
    start () {
        // [3]
            
    PhysicsSystem2D.instance.enable = true;
    PhysicsSystem2D.instance.debugDrawFlags = EPhysics2DDrawFlags.Aabb |
      EPhysics2DDrawFlags.Pair |
      EPhysics2DDrawFlags.CenterOfMass |
      EPhysics2DDrawFlags.Joint |
      EPhysics2DDrawFlags.Shape;
    // 注册单个碰撞体的回调函数
    let collider = this.node.getComponent(Collider2D);
    if (collider) {
      collider.on(Contact2DType.BEGIN_CONTACT, this.onBeginContact, this);
     
    }

    }

    private onBeginContact(selfCollider: Collider2D, otherCollider: Collider2D, contact: IPhysics2DContact | null){
        console.log(otherCollider.node.name);
        if( otherCollider.node.name!== "qiangbi"){
            otherCollider.node.active=false
            this.gouzi.showGold(otherCollider.node.name)
        }
        this.gouzi.backRoppe()
    }

}

