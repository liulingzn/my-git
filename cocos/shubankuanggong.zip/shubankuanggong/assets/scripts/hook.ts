
import { _decorator, Component, Node,UITransform ,instantiate, Prefab,SpriteFrame, Sprite, Label} from 'cc';
const { ccclass, property } = _decorator;

/**
 * Predefined variables
 * Name = hook
 * DateTime = Mon Apr 25 2022 14:58:18 GMT+0800 (中国标准时间)
 * Author = liulingzn
 * FileBasename = hook.ts
 * FileBasenameNoExtension = hook
 * URL = db://assets/scripts/hook.ts
 * ManualUrl = https://docs.cocos.com/creator/3.4/manual/zh/
 *
 */
const enum State{
    swing, //摆动
    throw,//抛出
    back,//返回
    fullload,//夹到了
    stop
}
class gameConfig {
    public static angleLeft=-50
    public static angleRight=50
    public static gouziHeight=215
}
 
@ccclass('hook')
export class hook extends Component {

    @property({type:Node,tooltip:"结束面板"})
    overGroup = null;

    @property({type:Node,tooltip:"成功"})
    wintext = null;

    @property({type:Node,tooltip:"失败"})
    losstext = null;
 
    @property({type:Node,tooltip:"得分"})
    myfraction = null;


    private myfractionLable:Label


    @property({type:Node,tooltip:"倒计时"})
    downTimer = null;


    private downTimerLable:Label


    @property({type:Prefab,tooltip:"炸弹"})
    boom = null;
    @property({type:SpriteFrame,tooltip:"炸弹图片"})
    boomImg:SpriteFrame=null


    @property({type:Prefab,tooltip:"金币包"})
    dialog_bag_golden_full = null;
    @property({type:SpriteFrame,tooltip:"金币包图片"})
    dialog_bag_golden_fullImg:SpriteFrame=null


    

    @property({type:Prefab,tooltip:"红包"})
    dialog_bag_hongbao_full = null;
    @property({type:SpriteFrame,tooltip:"红包图片"})
    dialog_bag_hongbao_fullImg:SpriteFrame=null

    
    @property({type:Prefab,tooltip:"金币1"})
    gold_1 = null;
    @property({type:SpriteFrame,tooltip:"金币1图片"})
    gold_1Img:SpriteFrame=null

    
    @property({type:Prefab,tooltip:"金币2"})
    gold_2 = null;
    @property({type:SpriteFrame,tooltip:"金币2图片"})
    gold_2Img:SpriteFrame=null

    
    @property({type:Prefab,tooltip:"金币3"})
    gold_3 = null;
    @property({type:SpriteFrame,tooltip:"金币3图片"})
    gold_3Img:SpriteFrame=null

    
    @property({type:Prefab,tooltip:"金币4"})
    gold_4 = null;
    @property({type:SpriteFrame,tooltip:"金币4图片"})
    gold_4Img:SpriteFrame=null

    


    private  throwSpeed=500
    private  swingSpeed=100

    private selfState
    private selfangle=0

    private zhuazi //爪子
    private zhuali  //爪子碰撞块

    private baowu

    private baowuSpriteFrame:Sprite

    private fraction:number=0
    private selfFraction:number=0

    private alltimer:number=60



    private isStart:boolean=false


    private gameover:boolean=false

    start () {
        // [3]
        this.myfractionLable=this.myfraction.getComponent(Label)
        this.downTimerLable=this.downTimer.getComponent(Label)
        this.overGroup.active=false

        this.selfState=State.swing
        this.zhuazi= this.getComponent(UITransform)
        this.zhuali=this.node.getChildByName("zhugou")
        this.baowu=this.node.getChildByName("baowu")
        this.baowu.active=false
        this.baowuSpriteFrame=this.baowu.getComponent(Sprite)

        // for (let i=0;i<5;i++) {
        //     this.shengchengjinkuang()
        //    }
    }


    shengchengjinkuang(){
        var jinzi
        let baotype=Math.floor(Math.random()*7+1) 
        switch(baotype){
            case 1:{
                jinzi=instantiate(this.boom)
            } break
            case 2:{
                jinzi=instantiate(this.dialog_bag_golden_full)
            } break
            // case 3:{
            //     jinzi=instantiate(this.dialog_bag_hongbao_full)
            // } break
            case 4:{
                jinzi=instantiate(this.gold_1)
            } break
            case 5:{
                jinzi=instantiate(this.gold_2)
            } break
            case 6:{
                jinzi=instantiate(this.gold_3)
            } break
            default:{
                jinzi=instantiate(this.gold_4)
            }
        }
      
        jinzi.setPosition(Math.random()*540-270,Math.random()*500-180)
        jinzi.parent=this.node.parent
    }

    update (dt: number) {
        if(this.gameover){
            return
        }
        // [4]
        if(this.selfState===State.swing){
            this.swingFunc(dt)
        }else if(this.selfState===State.throw){
            this.playthrow(dt)
        }else if(this.selfState===State.back){
            this.goBack(dt)
        }else{

        }

        if(!this.isStart){
            return
        }
        this.alltimer-=0.017
        if(this.alltimer<=0){
            this.alltimer=0
            this.downTimerLable.string= "倒计时：0秒"
            this.gameover=true



            if(this.fraction>200){
                this.wintext.active=true
                this.losstext.active=false
            }else{
                this.wintext.active=false
                this.losstext.active=true

            }

            this.overGroup.active=true
            return
        }

       this.downTimerLable.string= "倒计时：" +(this.alltimer.toFixed(2))+"秒"


    }
    public showGold(name:string):void {

        switch (name) {
            case "boom":{
                this.baowuSpriteFrame.spriteFrame=this.boomImg
                this.selfFraction=-100
            } break;

            case "dialog_bag_golden_full":{
                this.baowuSpriteFrame.spriteFrame=this.dialog_bag_golden_fullImg
                this.selfFraction=100
            } break;
            case "dialog_bag_hongbao_full":{
                this.baowuSpriteFrame.spriteFrame=this.dialog_bag_hongbao_fullImg
                this.selfFraction=200
            } break;

            case "gold_1":{
                this.baowuSpriteFrame.spriteFrame=this.gold_1Img
                this.selfFraction=10
            } break;
            case "gold_2":{
                this.baowuSpriteFrame.spriteFrame=this.gold_2Img

                this.selfFraction=20
            } break;

            case "gold_3":{
                this.baowuSpriteFrame.spriteFrame=this.gold_3Img
                this.selfFraction=30
            } break;
            case "gold_4":{
                this.baowuSpriteFrame.spriteFrame=this.gold_4Img
                this.selfFraction=40
            } break;

        }
        this.baowu.setPosition(0,this.zhuali.position.y,0)
        this.baowu.active=true
        this.throwSpeed=200
    }

    private swingFunc(dt: number):void{
        this.selfangle+=(this.swingSpeed*dt)
        this.node.angle=this.selfangle

        if(gameConfig.angleLeft>=this.selfangle&&this.swingSpeed<0){
            this.swingSpeed=-this.swingSpeed
        }else if(gameConfig.angleRight<=this.selfangle&&this.swingSpeed>0){
            this.swingSpeed=-this.swingSpeed
        } 
    }
    /**
     * 抛出绳子
     */
    public throw():void {
        console.log("pauc-------");
        if(this.selfState!==State.swing){
            return
        }
        this.selfState=State.throw
        if(!this.isStart){
            this.isStart=true
        }
    }

    private playthrow(dt: number):void{
        this.zhuazi.height += (this.throwSpeed*dt);


        let newy= this.zhuali.position.y-(this.throwSpeed*dt);
       
        this.zhuali.setPosition(0,newy,0)
        
    }

    public backRoppe():void{

        if(this.selfState!==State.throw){
            return
        }
        this.selfState=State.back

    }
    private goBack(dt:number):void{

        this.zhuazi.height -= (this.throwSpeed*dt);
        let newy= this.zhuali.position.y+(this.throwSpeed*dt);
        this.zhuali.setPosition(0,newy,0)
        this.baowu.setPosition(0,newy,0)

        if(this.zhuazi.height<=gameConfig.gouziHeight){
            this.zhuazi.height=gameConfig.gouziHeight
            this.baowu.active=false
            this.throwSpeed=500
            this.zhuali.setPosition(0,-175,0)
            this.selfState=State.swing
            this.fraction+=this.selfFraction
            this.myfractionLable.string=this.fraction+""
        }

    }
}

/**
 * [1] Class member could be defined like this.
 * [2] Use `property` decorator if your want the member to be serializable.
 * [3] Your initialization goes here.
 * [4] Your update function goes here.
 *
 * Learn more about scripting: https://docs.cocos.com/creator/3.4/manual/zh/scripting/
 * Learn more about CCClass: https://docs.cocos.com/creator/3.4/manual/zh/scripting/decorator.html
 * Learn more about life-cycle callbacks: https://docs.cocos.com/creator/3.4/manual/zh/scripting/life-cycle-callbacks.html
 */
