
import { _decorator, Component, Node, Event, director } from 'cc';
const { ccclass, property } = _decorator;


@ccclass('goGame')
export class goGame extends Component {

    onLoad () {
        this.node.on(Node.EventType.TOUCH_END,this.goTogame,this)
    }
    private goTogame(){
        
        director.loadScene('game');
    }
 
}

