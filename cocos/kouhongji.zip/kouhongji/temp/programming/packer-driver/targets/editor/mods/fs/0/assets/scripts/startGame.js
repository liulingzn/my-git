System.register(["cc"], function (_export, _context) {
  "use strict";

  var _cclegacy, _decorator, Component, Node, director, _dec, _class, _temp, _crd, ccclass, property, startGame;

  function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

  return {
    setters: [function (_cc) {
      _cclegacy = _cc.cclegacy;
      _decorator = _cc._decorator;
      Component = _cc.Component;
      Node = _cc.Node;
      director = _cc.director;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "b977e84cLhDLaQYdy6JzaJ4", "startGame", undefined);

      ({
        ccclass,
        property
      } = _decorator);
      /**
       * Predefined variables
       * Name = startGame
       * DateTime = Mon May 23 2022 16:02:13 GMT+0800 (中国标准时间)
       * Author = liulingzn
       * FileBasename = startGame.ts
       * FileBasenameNoExtension = startGame
       * URL = db://assets/scripts/startGame.ts
       * ManualUrl = https://docs.cocos.com/creator/3.4/manual/zh/
       *
       */

      _export("startGame", startGame = (_dec = ccclass('startGame'), _dec(_class = (_temp = class startGame extends Component {
        constructor(...args) {
          super(...args);

          _defineProperty(this, "homeInit", false);
        }

        onLoad() {
          var self = this;
          this.node.on(Node.EventType.TOUCH_END, this.gohome, this);
          director.preloadScene("home", function () {
            self.homeInit = true;
          });
        }

        gohome() {
          if (this.homeInit) {
            director.loadScene("home");
          }
        } // update (deltaTime: number) {
        //     // [4]
        // }


      }, _temp)) || _class));
      /**
       * [1] Class member could be defined like this.
       * [2] Use `property` decorator if your want the member to be serializable.
       * [3] Your initialization goes here.
       * [4] Your update function goes here.
       *
       * Learn more about scripting: https://docs.cocos.com/creator/3.4/manual/zh/scripting/
       * Learn more about CCClass: https://docs.cocos.com/creator/3.4/manual/zh/scripting/decorator.html
       * Learn more about life-cycle callbacks: https://docs.cocos.com/creator/3.4/manual/zh/scripting/life-cycle-callbacks.html
       */


      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=startGame.js.map