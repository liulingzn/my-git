System.register(["__unresolved_0", "cc", "__unresolved_1"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, _decorator, Component, Node, tween, Vec3, UITransform, Prefab, instantiate, audioFunc, _dec, _dec2, _dec3, _dec4, _dec5, _dec6, _dec7, _dec8, _dec9, _dec10, _dec11, _dec12, _dec13, _class, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4, _descriptor5, _descriptor6, _descriptor7, _descriptor8, _descriptor9, _descriptor10, _descriptor11, _descriptor12, _temp, _crd, ccclass, property, home;

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'proposal-class-properties is enabled and runs after the decorators transform.'); }

  function _reportPossibleCrUseOfaudioFunc(extras) {
    _reporterNs.report("audioFunc", "./audioFunc", _context.meta, extras);
  }

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
      _decorator = _cc._decorator;
      Component = _cc.Component;
      Node = _cc.Node;
      tween = _cc.tween;
      Vec3 = _cc.Vec3;
      UITransform = _cc.UITransform;
      Prefab = _cc.Prefab;
      instantiate = _cc.instantiate;
    }, function (_unresolved_2) {
      audioFunc = _unresolved_2.audioFunc;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "cf015r2noxGcIh1whA4vrnj", "home", undefined);

      ({
        ccclass,
        property
      } = _decorator);

      _export("home", home = (_dec = ccclass('home'), _dec2 = property({
        type: Node,
        tooltip: "发射飞刀按钮"
      }), _dec3 = property({
        type: Node,
        tooltip: "飞刀"
      }), _dec4 = property({
        type: Node,
        tooltip: "目标"
      }), _dec5 = property({
        type: Node,
        tooltip: "目标存放飞刀容器"
      }), _dec6 = property({
        type: Prefab,
        tooltip: "发出的飞刀"
      }), _dec7 = property({
        type: Node,
        tooltip: "剩余飞刀弹夹图"
      }), _dec8 = property({
        type: Node,
        tooltip: "粒子效果"
      }), _dec9 = property({
        type: _crd && audioFunc === void 0 ? (_reportPossibleCrUseOfaudioFunc({
          error: Error()
        }), audioFunc) : audioFunc,
        tooltip: "音效"
      }), _dec10 = property({
        type: Node,
        tooltip: "游戏结束group"
      }), _dec11 = property({
        type: Node,
        tooltip: "口红图片"
      }), _dec12 = property({
        type: Node,
        tooltip: "鼓励文字"
      }), _dec13 = property({
        type: Node,
        tooltip: "再玩一局"
      }), _dec(_class = (_class2 = (_temp = class home extends Component {
        constructor() {
          super(...arguments);

          _initializerDefineProperty(this, "emissionNode", _descriptor, this);

          _initializerDefineProperty(this, "knifeNode", _descriptor2, this);

          _initializerDefineProperty(this, "target", _descriptor3, this);

          _initializerDefineProperty(this, "newsknife", _descriptor4, this);

          _initializerDefineProperty(this, "knife", _descriptor5, this);

          _initializerDefineProperty(this, "knifeAllIcon", _descriptor6, this);

          _initializerDefineProperty(this, "lipstick", _descriptor7, this);

          _initializerDefineProperty(this, "audioEffect", _descriptor8, this);

          _initializerDefineProperty(this, "overGroup", _descriptor9, this);

          _initializerDefineProperty(this, "overIcon", _descriptor10, this);

          _initializerDefineProperty(this, "overText", _descriptor11, this);

          _initializerDefineProperty(this, "playAnotherGame", _descriptor12, this);

          _defineProperty(this, "knifeAllIconUITransform", void 0);

          _defineProperty(this, "isEmission", true);

          _defineProperty(this, "isGameOver", false);

          _defineProperty(this, "knifeAllNum", 10);

          _defineProperty(this, "speed", 200);

          _defineProperty(this, "locationLis", []);
        }

        playAudio(name) {
          this.audioEffect.play(name);
        }

        start() {// [3]
        }

        update(dt) {
          if (this.isGameOver) {
            return;
          } // [4]


          this.target.angle = Math.floor((this.speed * dt + this.target.angle) % 360); // console.log(this.lipstick.position);

          this.lipstick.angle = Math.floor(360 - (this.speed * dt + this.target.angle)); // this.lipstick.setPosition=new Vec3()
        }

        onLoad() {
          this.knifeAllIconUITransform = this.knifeAllIcon.getComponent(UITransform); // this.target.setSiblingIndex(10)

          this.emissionNode.on(Node.EventType.TOUCH_START, this.emission, this);
          this.overGroup.active = false;
          this.playAnotherGame.on(Node.EventType.TOUCH_END, this.againFunc, this); // const audioSource = this.getComponent(AudioSource)!;
          // assert(audioSource);
          // AudioManager.init(audioSource);
          // AudioManager.playMusic()
        }

        gameover(type) {
          this.overGroup.active = true;

          if (type === "loss") {
            this.overIcon.active = false;
            this.overText.active = true;
            this.playAudio("14481");
          } else {
            this.overText.active = false;
            this.overIcon.active = true;
            this.playAudio("4624");
          } // this.lipstick.active=false
          // this.newsknife.active=false

        }

        againFunc() {
          this.overGroup.active = false;
          this.knifeAllNum = 10;
          this.knifeAllIconUITransform.height = this.knifeAllNum * 36;
          this.isGameOver = false;
          this.isEmission = true;
          this.knifeNode.active = true;
          this.newsknife.removeAllChildren();
          this.locationLis = [];
        }

        emission() {
          if (this.isGameOver) {
            return;
          }

          if (!this.isEmission) {
            return;
          }

          this.isEmission = false;
          var flyingKnife = tween(this.knifeNode);
          flyingKnife.by(0.1, {
            position: new Vec3(0, 130, 0)
          });
          flyingKnife.call(() => {
            for (var i = 0; i < this.locationLis.length; i++) {
              if (Math.abs(this.locationLis[i] - this.target.angle) < 15) {
                this.gameover("loss");
                this.isGameOver = true;
                return;
              }
            }

            var feidaoNode = instantiate(this.knife);
            feidaoNode.angle = 360 - this.target.angle;
            feidaoNode.setPosition(new Vec3(0, 0, 0));
            this.newsknife.addChild(feidaoNode);
            this.knifeNode.active = false;
            this.locationLis.push(this.target.angle);
            this.playAudio("dong");
            var trembling = tween(this.target);
            trembling.by(0.05, {
              position: new Vec3(0, 10, 0)
            });
            trembling.by(0.03, {
              position: new Vec3(0, -10, 0)
            });
            trembling.start();
            this.knifeNode.setPosition(new Vec3(0, -130, 0));
            this.knifeAllNum -= 1;

            if (this.knifeAllNum >= 0) {
              this.knifeAllIconUITransform.height = this.knifeAllNum * 36;
              this.knifeNode.active = true;
              this.lipstick.active = true;
              this.isEmission = true;
            } else {
              this.gameover("");
              this.isGameOver = true;
            }
          });
          flyingKnife.start(); // let lipsticklz=tween(this.lipstick)
          // lipsticklz.by( 0.5, { position: new Vec3(0,130,0) })
          // lipsticklz.start()
        }

      }, _temp), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "emissionNode", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "knifeNode", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "target", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor4 = _applyDecoratedDescriptor(_class2.prototype, "newsknife", [_dec5], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor5 = _applyDecoratedDescriptor(_class2.prototype, "knife", [_dec6], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor6 = _applyDecoratedDescriptor(_class2.prototype, "knifeAllIcon", [_dec7], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor7 = _applyDecoratedDescriptor(_class2.prototype, "lipstick", [_dec8], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor8 = _applyDecoratedDescriptor(_class2.prototype, "audioEffect", [_dec9], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor9 = _applyDecoratedDescriptor(_class2.prototype, "overGroup", [_dec10], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor10 = _applyDecoratedDescriptor(_class2.prototype, "overIcon", [_dec11], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor11 = _applyDecoratedDescriptor(_class2.prototype, "overText", [_dec12], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor12 = _applyDecoratedDescriptor(_class2.prototype, "playAnotherGame", [_dec13], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      })), _class2)) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=home.js.map