
import { _decorator, Component, Node, AudioClip, AudioSource } from 'cc';
const { ccclass, property } = _decorator;

interface IAudioMap{
    [name:string]:AudioClip
}   
 
@ccclass('audioFunc')
export class audioFunc extends Component {
   
    @property ([AudioClip])
    public audioList:AudioClip[]=[]

    private _dict:IAudioMap={}

    private _audioSource:AudioSource=null
    start () {
        for (let i = 0; i < this.audioList.length; i++) {
            const element = this.audioList[i];
            this._dict[element.name]=element
            
        }
        this._audioSource=this.getComponent(AudioSource)
    }
    // onLoad(){
    //     for (let i = 0; i < this.audioList.length; i++) {
    //         const element = this.audioList[i];
    //         this._dict[element.name]=element
            
    //     }
    //     this._audioSource=this.getComponent(AudioSource)
    // }

    public play(name:string):void{
        const audioClip=this._dict[name]
        if(audioClip!==undefined){
            this._audioSource.playOneShot(audioClip)
        }
    }
}

