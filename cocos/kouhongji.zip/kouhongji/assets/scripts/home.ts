
import { _decorator, Component,AudioSource, assert,Node, tween,Vec3,UITransform, Prefab ,instantiate, Vec2, ParticleSystem2D} from 'cc';
import { audioFunc } from './audioFunc';
const { ccclass, property } = _decorator;

import {AudioManager} from "./AudioManager"
 
@ccclass('home')
export class home extends Component {

    @property({type:Node,tooltip:"发射飞刀按钮"})
    emissionNode=null
    
    @property({type:Node,tooltip:"飞刀"})
    knifeNode=null


    @property({type:Node,tooltip:"目标"})
    target=null

    @property({type:Node,tooltip:"目标存放飞刀容器"})
    newsknife:Node=null

    @property({type:Prefab,tooltip:"发出的飞刀"})
    knife=null

    @property({type:Node,tooltip:"剩余飞刀弹夹图"})
    knifeAllIcon=null


    @property({type:Node,tooltip:"粒子效果"})
    lipstick=null


    @property({type:audioFunc,tooltip:"音效"})
    public audioEffect:audioFunc=null

    @property({type:Node,tooltip:"游戏结束group"})
    public overGroup:Node=null

    @property({type:Node,tooltip:"口红图片"})
    public overIcon:Node=null

    @property({type:Node,tooltip:"鼓励文字"})
    public overText:Node=null

    @property({type:Node,tooltip:"再玩一局"})
    public playAnotherGame:Node=null

    private knifeAllIconUITransform:UITransform

    private isEmission=true
    private isGameOver=false

    private knifeAllNum=10

    private speed=200


    private locationLis:number[]=[]

    public playAudio(name:string):void{
        this.audioEffect.play(name)
    }
    start () {
        // [3]
    }

    update (dt: number) {
        if(this.isGameOver){
            return
        }
        // [4]
        this.target.angle= Math.floor((this.speed*dt+this.target.angle)%360) 
        // console.log(this.lipstick.position);
        this.lipstick.angle= Math.floor(360- (this.speed*dt+this.target.angle)) 
        // this.lipstick.setPosition=new Vec3()
    }
    onLoad(){
        this.knifeAllIconUITransform=this.knifeAllIcon.getComponent(UITransform)
        // this.target.setSiblingIndex(10)

        this.emissionNode.on(Node.EventType.TOUCH_START, this.emission, this)

        this.overGroup.active=false

        this.playAnotherGame.on(Node.EventType.TOUCH_END,this.againFunc,this)
        
        // const audioSource = this.getComponent(AudioSource)!;
        // assert(audioSource);
        // AudioManager.init(audioSource);

        // AudioManager.playMusic()
    }
    public gameover(type){
        this.overGroup.active=true
        if(type==="loss"){
            this.overIcon.active=false
            this.overText.active=true

            this.playAudio("14481")
        }else{
            this.overText.active=false
            this.overIcon.active=true
            this.playAudio("4624")
            
        }

        // this.lipstick.active=false
        // this.newsknife.active=false
    }
    public againFunc(){
        this.overGroup.active=false
        this.knifeAllNum=10
        this.knifeAllIconUITransform.height=this.knifeAllNum*36
        this.isGameOver=false
        this.isEmission=true
        this.knifeNode.active=true
        this.newsknife.removeAllChildren()
        this.locationLis=[]
    }
    private emission():void{
        if(this.isGameOver){
            return
        }
        if(!this.isEmission){
            return
        }
        this.isEmission=false
        let flyingKnife=tween(this.knifeNode)
        flyingKnife.by( 0.1, { position: new Vec3(0,130,0) })
        flyingKnife.call(() => {

          for(let i=0;i<this.locationLis.length;i++){
              
              if(Math.abs(this.locationLis[i]-this.target.angle)<15){
                this.gameover("loss")
                this.isGameOver=true
                  return
              }
          }
            
            let feidaoNode=instantiate(this.knife)
            feidaoNode.angle=360- this.target.angle
            feidaoNode.setPosition(new Vec3(0,0,0))
            this.newsknife.addChild(feidaoNode)
            this.knifeNode.active=false
            this.locationLis.push(this.target.angle);
            this.playAudio("dong")

            let trembling=tween(this.target)
            trembling.by( 0.05, { position: new Vec3(0,10,0) })
            trembling.by( 0.03, { position: new Vec3(0,-10,0) })
            trembling.start()


            this.knifeNode.setPosition(new Vec3(0,-130,0))
            this.knifeAllNum-=1
            if(this.knifeAllNum>=0){
                this.knifeAllIconUITransform.height=this.knifeAllNum*36
                this.knifeNode.active=true
                this.lipstick.active=true
                this.isEmission=true

            }else{
                this.gameover("")
                this.isGameOver=true
            }
           
        })
       
        flyingKnife.start()




        

        // let lipsticklz=tween(this.lipstick)
        // lipsticklz.by( 0.5, { position: new Vec3(0,130,0) })
        // lipsticklz.start()
    }   
}

