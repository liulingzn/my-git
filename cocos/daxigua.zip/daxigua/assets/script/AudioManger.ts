
import { _decorator, Component, Node, AudioClip, AudioSource } from 'cc';
const { ccclass, property } = _decorator;

/**
 * Predefined variables
 * Name = AudioManger
 * DateTime = Wed Jun 01 2022 18:59:40 GMT+0800 (中国标准时间)
 * Author = liulingzn
 * FileBasename = AudioManger.ts
 * FileBasenameNoExtension = AudioManger
 * URL = db://assets/script/framework/AudioManger.ts
 * ManualUrl = https://docs.cocos.com/creator/3.4/manual/zh/
 *
 */
interface IAudioMap {
    [name: string]: AudioClip
}

@ccclass('AudioManger')
export class AudioManger extends Component {

    @property({ type: [AudioClip], tooltip: "音效库" })
    public audioList: AudioClip[] = []



    public _dico: IAudioMap = {}

    public _audioSoucre: AudioSource = null;
    start() {

        for (let i = 0; i < this.audioList.length; i++) {
            const element = this.audioList[i];
            this._dico[element.name] = element
        }
        this._audioSoucre = this.getComponent(AudioSource)
    }


    public playEffect(name: string) {

        const audioClip =this._dico[name]
        if(audioClip!==undefined){
            this._audioSoucre.playOneShot(audioClip)
        }
    }

}

