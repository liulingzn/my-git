import { _decorator, Component, Node, PhysicsSystem2D, EPhysics2DDrawFlags, Prefab, instantiate, Vec3, SpriteFrame, AudioClip, CCInteger, math, Label } from 'cc';
import { itemContent } from './itemContent';
import { effectscc } from './effectscc';
import { AudioManger } from './AudioManger';
const { ccclass, property } = _decorator;


@ccclass("FruitItem")
export class FruitItem {
    @property({ type: Number })
    public id: number = 1;
    @property({ type: SpriteFrame })
    public img: SpriteFrame = null!;
    @property({ type: Number })
    public radius: number = 1;

}


@ccclass('physitMar')
export class physitMar extends Component {

    @property({ type: Boolean, tooltip: "是否开启物理debug" })
    public isShowDebug = false;

    @property({ type: Node, tooltip: "点击生成" })
    public produceBut: Node = null;

    @property({ type: Prefab, tooltip: "水果" })
    private fruit1: Prefab = null;

    @property({ type: Node, tooltip: "水果" })
    private selfFruitGroup: Node = null;


    @property({ type: FruitItem, tooltip: "水果材料" })
    public fruits: FruitItem[] = [];


    @property({ type: Prefab, tooltip: "爆炸" })
    public selfexplode: Prefab = null;


    @property({ type: SpriteFrame, tooltip: "爆炸材料" })
    public explode: SpriteFrame[] = [];

    @property({ type: Label, tooltip: "得分数" })
    public myScore: Label = null;

    @property({type:Node,tooltip:"得分group"})
    public overGroup :Node =null;

    @property({type:Node,tooltip:"胜利group"})
    public winoverGroup :Node =null;

    @property({type:Label,tooltip:"结束得分"})
    public finallyScore :Label =null;

    @property ({type:AudioManger,tooltip:"音效"})
    public audioEffect:AudioManger=null;

    

    public mergeSpacingNum: number = 0;

    public myScoreNumber: number = 0;


    public isGenerate: boolean = true;

    private isGameOver :boolean =false;
    start() {

    }
    onLoad() {
        PhysicsSystem2D.instance.enable = true
        if (this.isShowDebug) {
            PhysicsSystem2D.instance.debugDrawFlags = EPhysics2DDrawFlags.All
        } else {
            PhysicsSystem2D.instance.debugDrawFlags = EPhysics2DDrawFlags.None

        }

        this.produceBut.on(Node.EventType.TOUCH_END, this.produce, this)
    }

    private produce() {

       
        
        if(this.isGameOver){
            return
        }
        if (!this.isGenerate) {
            return
        }
        this.audioEffect.playEffect('knock')
        this.mergeSpacingNum=0;
        this.isGenerate = false;
        const nums = math.randomRangeInt(1, 6)
        const config = this.fruits[nums - 1]


        let fruit = instantiate(this.fruit1)
        let fruitCom = fruit.getComponent(itemContent)
        fruitCom.fruitInit(config, this)
        fruit.setPosition(new Vec3(Math.floor(Math.random() * 400 - 200), 560, 0))


        this.selfFruitGroup.addChild(fruit)


    }

    public newFruit(index: number, pos: Vec3) {


        const config = this.fruits[index];
        let fruit = instantiate(this.fruit1);
        let fruitCom = fruit.getComponent(itemContent);
        fruitCom.fruitInit(config, this);
        fruit.setPosition(pos);


        this.selfFruitGroup.addChild(fruit);

        this.myScoreNumber++;

        this.myScore.string = "SCORE : " + this.myScoreNumber;
        this.audioEffect.playEffect('boom')
    }

    public explodeFunc(index: number, pos: Vec3) {
        let explodes = instantiate(this.selfexplode);
        let fruitCom = explodes.getComponent(effectscc);
        fruitCom.initIcon(this.explode[index - 1]);
        explodes.setPosition(pos);

        this.selfFruitGroup.addChild(explodes);


    }



    public getFruitItem(id: number): FruitItem {
        return this.fruits[id]
    }


    public gameOverFunc(){
        this.overGroup.active=true;
        this.finallyScore.string=this.myScoreNumber+"分数";
        this.isGameOver=true;
    }

    public winFunc(){
        
        this.winoverGroup.active=true;
        this.isGameOver=true;

    }

    update(deltaTime: number) {
       

       this.mergeSpacingNum++
       if(this.mergeSpacingNum>90){
         this.isGenerate=true
         this.mergeSpacingNum=0
       }
    }
    public self() {
        console.log("碰上了");

    }
}

