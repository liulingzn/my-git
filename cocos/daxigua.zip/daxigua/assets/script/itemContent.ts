import { _decorator, Component, Node, BoxCollider2D, BoxCollider, Contact2DType, CircleCollider2D, Sprite, Script, RigidBody2D, Vec3 } from 'cc';
import { physitMar } from './physitMar';

const { ccclass, property } = _decorator;
@ccclass('itemContent')
export class itemContent extends Component {



    private collderBox: CircleCollider2D = null
    private RigidBody: RigidBody2D = null

    public radiusNum: number = 0

    private id: number = 0;

    private _physitMar: physitMar = null;
    onLoad() {
        //获取物理事件
        this.collderBox = this.node.getComponent(CircleCollider2D)
        this.RigidBody = this.node.getComponent(RigidBody2D)


        //监听碰撞
        this.collderBox.on(Contact2DType.BEGIN_CONTACT, this.OnBeginContant, this)
        // console.log(physitMar);
        if (this.radiusNum > 0) {

            this.collderBox.radius = this.radiusNum;

        }
    }

    public fruitInit(data: any, mar: physitMar) {
        this.id = data.id;
        const sp: Sprite = this.getComponent(Sprite)
        sp.spriteFrame = data.img;
        this._physitMar = mar;
        if (this.collderBox) {
            this.collderBox.radius = data.radius
        } else {
            this.radiusNum = data.radius
        }


    }

    public pengshangle() {
        console.log(999);
        // this.collderBox.destroy();
        // this.RigidBody.destroy();
        // this.node.destroy();

    }

    private OnBeginContant(self, other): void {
        // console.log("碰上了",self);
        // console.log("碰上了",self.node。id);
        let fruit = self.node.getComponent(itemContent);


        // fruit.pengshangle()
        if (self.node.position.y+fruit.radiusNum > 530) {

            console.log("gameover");
            this._physitMar.gameOverFunc()
        }
        
        // console.log("---------", self.node.position.y > 554);
        let fruitOther = other.node.getComponent(itemContent);
        if (fruitOther) {
            if (fruit.id == fruitOther.id) {
                
                this.scheduleOnce(() => {

                    if (self.node) {
                        const pos = self.node.position;
                        self.node.destroy();
                        this._physitMar.newFruit(Number(fruitOther.id), pos);

                        if(Number(fruitOther.id)>=10){
                            this._physitMar.winFunc()
                        }
                    }
                    if (other.node) {
                        const pos = other.node.position;

                        this._physitMar.explodeFunc(Number(fruitOther.id), pos);

                        other.node.destroy();
                        // this._physitMar.newFruit(Number(fruitOther.id), pos);
                    }


                }, 0)

            }
        }

        // self.destroy();
        // this.node.destroy()
        // self.node.destroy();
        // this.node.destroy();

        // this.fruitRefresh(this._physitMar.getFruitItem(5))
        // this.fruitInit()

    }

    private fruitRefresh(data: any) {
        const sp: Sprite = this.getComponent(Sprite)
        sp.spriteFrame = data.img;
        this.collderBox.radius = data.radius


    }

}

