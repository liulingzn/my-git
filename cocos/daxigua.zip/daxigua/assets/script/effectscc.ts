import { _decorator, Component, Node, tween, Vec2, Vec3, UIOpacity, SpriteFrame, Sprite } from 'cc';
const { ccclass, property } = _decorator;

@ccclass('effectscc')
export class effectscc extends Component {
    start() {

    }
    private selfOpacity: UIOpacity = null;
    onLoad() {
        this.selfOpacity = this.getComponent(UIOpacity);
        let explode = tween(this.selfOpacity);
        explode.to(0.3, { opacity: 255 });
        explode.call(() => {
            this.node.destroy();
        })
        explode.start();


    }

    public initIcon(frame: SpriteFrame) {
        let _sprite = this.node.getComponent(Sprite)
        _sprite.spriteFrame = frame

    }


}

