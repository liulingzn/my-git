System.register(["cc"], function (_export, _context) {
  "use strict";

  var _cclegacy, _decorator, Component, Sprite, _dec, _class, _temp, _crd, ccclass, property, huangxing;

  function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

  return {
    setters: [function (_cc) {
      _cclegacy = _cc.cclegacy;
      _decorator = _cc._decorator;
      Component = _cc.Component;
      Sprite = _cc.Sprite;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "b5710gLJa9EBLgp4RTdsNVT", "huangxing", undefined);

      ({
        ccclass,
        property
      } = _decorator);
      /**
       * 环形进度条
       *
       */

      _export("huangxing", huangxing = (_dec = ccclass('huangxing'), _dec(_class = (_temp = class huangxing extends Component {
        constructor() {
          super(...arguments);

          _defineProperty(this, "sprite", void 0);

          _defineProperty(this, "loadStart", 0);

          _defineProperty(this, "loadEnd", 2);

          _defineProperty(this, "zheng", true);
        }

        onLoad() {
          this.sprite = this.node.getComponent(Sprite);
        }

        update(dt) {
          // [4]
          if (this.zheng) {
            this.loadStart += dt;
          } else {
            this.loadStart -= dt;
          }

          if (this.loadStart > this.loadEnd) {
            this.loadStart = this.loadEnd;
            this.zheng = false;
          } else if (this.loadStart <= 0) {
            this.loadStart = 0;
            this.zheng = true;
          }

          var fangxinag = this.zheng ? 1 : -1;
          this.sprite.fillRange = this.loadStart / this.loadEnd * fangxinag;
        }

      }, _temp)) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=huangxing.js.map