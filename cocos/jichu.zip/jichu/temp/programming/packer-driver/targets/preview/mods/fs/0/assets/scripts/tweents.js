System.register(["cc"], function (_export, _context) {
  "use strict";

  var _cclegacy, _decorator, Component, tween, Vec3, _dec, _class, _crd, ccclass, property, tweents;

  return {
    setters: [function (_cc) {
      _cclegacy = _cc.cclegacy;
      _decorator = _cc._decorator;
      Component = _cc.Component;
      tween = _cc.tween;
      Vec3 = _cc.Vec3;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "a1f42tuVbdHL7Q7OM6seRL9", "tweents", undefined);

      ({
        ccclass,
        property
      } = _decorator);

      _export("tweents", tweents = (_dec = ccclass('tweents'), _dec(_class = class tweents extends Component {
        onLoad() {
          tween(this.node).sequence(tween().to(0.5, {
            position: new Vec3(200, -200, 0)
          }), tween().to(0.5, {
            position: new Vec3(-300, -200, 0)
          })) // .repeatForever() 
          .repeat(10) // .to(2,{position:new Vec3(200,-200,0)})
          // .repeatForever()   
          .call(() => {
            console.log("动画播放完了");
          }).start(); // 本地储存
          // localStorage.setItem("key:String","value:String")
          // var data=localStorage.getItem("key:String")
          // localStorage.removeItem("key:String")
        }

      }) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=tweents.js.map