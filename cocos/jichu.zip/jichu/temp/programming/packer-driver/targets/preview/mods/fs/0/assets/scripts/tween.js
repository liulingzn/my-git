System.register(["cc"], function (_export, _context) {
  "use strict";

  var _cclegacy, _decorator, Component, tween, Vec3, _dec, _class, _crd, ccclass, property, tweents;

  return {
    setters: [function (_cc) {
      _cclegacy = _cc.cclegacy;
      _decorator = _cc._decorator;
      Component = _cc.Component;
      tween = _cc.tween;
      Vec3 = _cc.Vec3;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "85cd4Lg+v1Ae4iHBqRuYxf5", "tween", undefined);

      ({
        ccclass,
        property
      } = _decorator);

      _export("tweents", tweents = (_dec = ccclass('tween'), _dec(_class = class tweents extends Component {
        onload() {
          var donghua = tween(this.node);
          donghua.by(1, {
            position: new Vec3(200, 0, 0)
          });
          donghua.start();
        }

      }) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=tween.js.map