System.register(["__unresolved_0", "__unresolved_1", "__unresolved_2", "__unresolved_3"], function (_export, _context) {
  "use strict";

  return {
    setters: [function (_unresolved_) {}, function (_unresolved_2) {}, function (_unresolved_3) {}, function (_unresolved_4) {}],
    execute: function () {}
  };
});
//# sourceMappingURL=prerequisite-imports.js.map