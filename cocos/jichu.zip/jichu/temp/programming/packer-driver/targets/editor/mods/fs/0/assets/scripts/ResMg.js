System.register(["cc"], function (_export, _context) {
  "use strict";

  var _cclegacy, _decorator, Component, assetManager, SpriteAtlas, _dec, _class, _crd, ccclass, property, ResMg;

  return {
    setters: [function (_cc) {
      _cclegacy = _cc.cclegacy;
      _decorator = _cc._decorator;
      Component = _cc.Component;
      assetManager = _cc.assetManager;
      SpriteAtlas = _cc.SpriteAtlas;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "6c1deCM3HlC0oOpuMWMw05Y", "ResMg", undefined);

      ({
        ccclass,
        property
      } = _decorator);
      /**
       * 
       *  加载ab包
       */

      _export("ResMg", ResMg = (_dec = ccclass('ResMg'), _dec(_class = class ResMg extends Component {
        onLoad() {
          let bundle = null; //异步加载   bundle  只能在回掉里面使用

          assetManager.loadBundle("game", (err, ab) => {
            if (err) {
              console.log(err);
              return;
            }

            bundle = ab;
          });
        }

        bundleGet(bund) {
          bund.load("poke", SpriteAtlas, (err, atlas) => {
            if (err) {
              console.log(err);
              return;
            }

            this.changeSprin(atlas);
          });
        }

        changeSprin(atlas) {
          let zy = atlas.getSpriteFrame("c12");
        }

      }) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=ResMg.js.map