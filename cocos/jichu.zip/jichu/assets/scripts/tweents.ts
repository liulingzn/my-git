
import { _decorator, Component, Node,tween, Vec3, Tween } from 'cc';
const { ccclass, property } = _decorator;


 
@ccclass('tweents')
export class tweents extends Component {
 

    onLoad(){
        tween(this.node)
        .sequence(

            tween().to(0.5,{position:new Vec3(200,-200,0)}),
            tween().to(0.5,{position:new Vec3(-300,-200,0)})
        )
        // .repeatForever() 
        .repeat(10)
        // .to(2,{position:new Vec3(200,-200,0)})
        
        // .repeatForever()   
        .call(()=>{
                console.log("动画播放完了");
                
        })
        .start()

        // 本地储存

        // localStorage.setItem("key:String","value:String")
        // var data=localStorage.getItem("key:String")
        // localStorage.removeItem("key:String")
    }
}


