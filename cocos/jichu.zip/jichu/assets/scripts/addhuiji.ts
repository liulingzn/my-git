
import { _decorator, Component, Node, FixedJoint2D, Prefab, instantiate, Sprite ,SpriteFrame} from 'cc';
const { ccclass, property } = _decorator;

/**
 * Predefined variables
 * Name = addhuiji
 * DateTime = Sun Apr 24 2022 15:49:56 GMT+0800 (中国标准时间)
 * Author = liulingzn
 * FileBasename = addhuiji.ts
 * FileBasenameNoExtension = addhuiji
 * URL = db://assets/scripts/addhuiji.ts
 * ManualUrl = https://docs.cocos.com/creator/3.4/manual/zh/
 *
 */
 
@ccclass('addhuiji')
export class addhuiji extends Component {
    // [1]
    // dummy = '';

    // [2]
    // @property
    // serializableDummy = 0;

    @property({type:Prefab,tooltip:"飞机预制"})
    yuzhifeiji:Prefab =null


    @property({type:SpriteFrame,tooltip:"图片资源"})
    imgUrl:SpriteFrame=null


    start () {
        // [3]
        this.node.on(Node.EventType.TOUCH_START,this.jiafeiji,this)
    }

    jiafeiji(){
        console.log("点击了----");
        //预制体 使用
        let feiji =instantiate(this.yuzhifeiji)
        feiji.parent=this.node
        feiji.setPosition(Math.random()*840-430,Math.random()*400-200)
        
    }

    onLoad(){
        // 替换图片素材
        let sprite= this.node.getComponent(Sprite)
        sprite.spriteFrame=this.imgUrl

    }
    // update (deltaTime: number) {
    //     // [4]
    // }
}

