
import { _decorator, Component, Node, AssetManager, assetManager, SpriteAtlas } from 'cc';
const { ccclass, property } = _decorator;

/**
 * 
 *  加载ab包
 */
 
@ccclass('ResMg')
export class ResMg extends Component {
  
    onLoad():void{
        let bundle:AssetManager.Bundle=null

            //异步加载   bundle  只能在回掉里面使用
            assetManager.loadBundle("game",(err,ab:AssetManager.Bundle)=>{
                if(err){
                    console.log(err);
                    return
                    
                }
                bundle=ab

            })
    }

    private bundleGet(bund:AssetManager.Bundle):void{
        bund.load("poke",SpriteAtlas,(err,atlas)=>{
            if(err){
                console.log(err);
                
                return
            }
            this.changeSprin(atlas)
        })
    }
    private changeSprin(atlas:SpriteAtlas):void{
        let zy=atlas.getSpriteFrame("c12")
    }
}


