
import { _decorator, Component, Node, Sprite } from 'cc';
const { ccclass, property } = _decorator;

/**
 * 环形进度条
 *
 */
 
@ccclass('huangxing')
export class huangxing extends Component {
    // [1]
    // dummy = '';

    // [2]
    // @property
    // serializableDummy = 0;

    private sprite:Sprite

    private loadStart=0
    private loadEnd=2
    private zheng=true

    onLoad(){
        this.sprite=this.node.getComponent(Sprite)
    }
    update (dt: number) {
        // [4]
        if(this.zheng){
            this.loadStart+=dt
        }else{
            this.loadStart-=dt
        }
       
        if(this.loadStart>this.loadEnd){
            this.loadStart=this.loadEnd
            this.zheng=false
        }else if(this.loadStart<=0){
            this.loadStart=0
            this.zheng=true
        }
        let fangxinag= this.zheng?1:-1
        this.sprite.fillRange=(this.loadStart/this.loadEnd)*fangxinag
    }
}

 